# MEC-830-project-2-
Build and design a robotic car that will be able to be manually and autonomously controlled to track a path and avoid obstacles

The Repo is used as a version control for the four tasks required for completion of the project

![alt text](https://github.com/Ericpijano/MEC-830-project-2-/blob/main/mec830%20project%202%20picture%202.JPG)

Task_1: Manual control of the robotic car using an IR Remote <br />
Task_2: Control the robotic car to follow a set path autonomously using the usage of sensors and actuators <br />
Task_3: Obstacle Avoidance; Control the robotic car autonomously so that it will travel from point A to point B and avoid an obstacle that is placed in its line of view <br />
Task_4: Autonomously control the robotic car to travel in square <br />

by eric pijano
  jayson tong
